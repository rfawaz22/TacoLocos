package com.example.tacolocos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TacoLocosApplicationTests {

    @Test
    void contextLoads() {
    }

}
